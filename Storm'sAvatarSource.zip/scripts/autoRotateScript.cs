﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class autoRotateScript : MonoBehaviour {

    public float rotateX;
    public float rotateY;
    public float rotateZ;

    public float wRotateX;
    public float wRotateY;
    public float wRotateZ;

    Vector3 localRotateVector;
    Vector3 worldRotateVector;

    // Use this for initialization
    void Start () {
        localRotateVector = transform.localEulerAngles;
        worldRotateVector = transform.eulerAngles;

    }
	
	// Update is called once per frame
	void Update () {
        localRotateVector += new Vector3(rotateX, rotateY, rotateZ);
        worldRotateVector += new Vector3(wRotateX, wRotateY, wRotateZ);

        transform.eulerAngles = worldRotateVector;
        transform.localEulerAngles = localRotateVector;
        
    }
}
