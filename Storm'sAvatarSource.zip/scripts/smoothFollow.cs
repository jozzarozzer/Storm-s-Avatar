﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class smoothFollow : MonoBehaviour {

    public GameObject followObj;
    public Vector3 targetPosition;
    public Vector3 offset;

    ShakeCamera cameraShake;
    
    public float lerpAmount;

	// Use this for initialization
	void Start () {
        cameraShake = GetComponent<ShakeCamera>();
	}
	
	// Update is called once per frame
	void Update () {
        targetPosition = followObj.transform.position + offset;

        var targetLookPosition2 = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        var averagePosition = (targetLookPosition2 + targetPosition) / 2;
        var finalTarget = new Vector3(averagePosition.x, averagePosition.y, -500);

        if (!cameraShake.shaking)
        {
            if (Input.GetKey(KeyCode.LeftShift))
            {
                transform.position = Vector3.Lerp(transform.position, finalTarget, 0.6f);
                //transform.position = Vector3.Lerp(transform.position, targetLookPosition2, lerpAmount * 2);
            }
            else transform.position = Vector3.Lerp(transform.position, targetPosition, lerpAmount);
        }
        else if (cameraShake.shaking)
        {
            if (Input.GetKey(KeyCode.LeftShift))
            {
                transform.position = Vector3.Lerp(transform.position, finalTarget, 0.6f) + Random.insideUnitSphere * cameraShake.amp;
                //transform.position = Vector3.Lerp(transform.position, targetLookPosition2, lerpAmount * 2);
            }
            else transform.position = Vector3.Lerp(transform.position, targetPosition, lerpAmount) + Random.insideUnitSphere * cameraShake.amp;
        }
    }
}
