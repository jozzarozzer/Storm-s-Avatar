﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gunHolderController : MonoBehaviour {

    Vector2 targetLookPosition2;
    Vector3 targetLookPosition3;
    Vector3 targetMovePosition;

    public GameObject playerObj;
    playerController playerScript;

    public AudioSource audioSource;
    public AudioClip shoot1;
    public AudioClip shoot2;
    public AudioClip shoot3;
    public AudioClip shoot4;

    public GameObject pistolBullet;

    private float angle;
    private float posX;
    private float posY;
    private float riseRun;

    public GameObject cameraObj;
    ShakeCamera cameraShake;

    public float distanceFromPlayer = 100;

	// Use this for initialization
	void Start () {
        playerScript = playerObj.GetComponent<playerController>();
        cameraShake = cameraObj.GetComponent<ShakeCamera>();

    }
	
	// Update is called once per frame
	void Update () {
        targetLookPosition2 = Input.mousePosition;
        targetLookPosition2 = Camera.main.ScreenToWorldPoint(targetLookPosition2);
        targetLookPosition3 = new Vector3(targetLookPosition2.x, targetLookPosition2.y, -10);

        var xDifference = targetLookPosition3.x - playerObj.transform.position.x;
        var yDifference = targetLookPosition3.y - playerObj.transform.position.y;


        if (targetLookPosition3.x >= transform.position.x)
        {
            riseRun = yDifference / xDifference;
            angle = Mathf.Atan(riseRun);
            posX = Mathf.Cos(angle);
            posY = Mathf.Sin(angle);
        }
        else
        {
            angle = - Mathf.Atan(yDifference / xDifference);
            posX = -Mathf.Cos(angle);
            posY = Mathf.Sin(angle);
        }



        targetMovePosition = new Vector3(distanceFromPlayer * posX, distanceFromPlayer * posY, 0);


        transform.position = targetMovePosition + playerObj.transform.position;



        if (Input.GetMouseButtonDown(0))
        {
            var targetPos = new Vector3 (posX, posY, -10);
            var bulletSpeed = 40;
            var shootCost = 10;
            Shoot(targetPos, bulletSpeed, shootCost);
        }

        
    }

    void Shoot(Vector3 targetPos, float speed, float shootCost)
    {
        if (playerScript.powerCurrent >= shootCost)
        {
            GameObject bullet = Instantiate(pistolBullet) as GameObject;
            bullet.GetComponent<bulletController>().playerPosition = playerObj.transform.position;
            bullet.transform.position = transform.position;
            bullet.GetComponent<bulletController>().SetValues(targetPos, speed);
            playerScript.powerCurrent -= shootCost;
            cameraShake.Shake(0.1f, 35);

            var randNum = Random.Range(1, 5);
            if (randNum == 1) audioSource.clip = shoot1;
            if (randNum == 2) audioSource.clip = shoot2;
            if (randNum == 3) audioSource.clip = shoot3;
            if (randNum == 4) audioSource.clip = shoot4;
            audioSource.pitch = Random.Range(0.9f, 1.1f);
            audioSource.Play();

        }
        else
        {
            //can't shoot
        }
    }
}
