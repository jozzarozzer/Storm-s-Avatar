﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyController : MonoBehaviour {

    public GameObject playerObj;
    playerController playerScript;

    public GameObject sightObj;
    public detectSight sightScript;
    bool playerInSight;

    Vector3 moveVector;
    Vector3 targetPosition;
    public float moveSpeed;

    public float healthCurrent;
    public float healthMax;

    public LayerMask hitFilterMask;

    BoxCollider2D selfCollider;
    
    public bool dead;

    SpriteRenderer spriteRenderer;

    bool collideUp;
    bool collideDown;
    bool collideLeft;
    bool collideRight;

    public bool canBePickedUp = false;
    public bool isPickedUp = false;
    public bool touchingPlayer = false;
    public bool heldByPlayer = false;
    Vector3 heldVectorDifference;

    public AudioSource audioSource1;
    public AudioClip enemyHurt1;

	// Use this for initialization
	void Start () {
        playerScript = playerObj.GetComponent<playerController>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        GameObject sightInstance = Instantiate(sightObj) as GameObject;
        sightInstance.GetComponent<detectSight>().followObj = gameObject;

        sightScript = sightInstance.GetComponent<detectSight>();

        selfCollider = GetComponent<BoxCollider2D>();
	}
	
	// Update is called once per frame
	void Update () {


        playerInSight = sightScript.playerInSight;

        if (!dead && playerInSight)
        {
            targetPosition = playerObj.transform.position;

            moveVector = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed);

            //start top left, clockwise
            var boxCorner1 = new Vector3(transform.position.x - selfCollider.size.x / 2 -10, transform.position.y + selfCollider.size.y / 2 +10, transform.position.z);
            var boxCorner2 = new Vector3(transform.position.x + selfCollider.size.x / 2 +10, transform.position.y + selfCollider.size.y / 2 +10, transform.position.z);
            var boxCorner3 = new Vector3(transform.position.x + selfCollider.size.x / 2 +10, transform.position.y - selfCollider.size.y / 2 -10, transform.position.z);
            var boxCorner4 = new Vector3(transform.position.x - selfCollider.size.x / 2 -10, transform.position.y - selfCollider.size.y / 2 -10, transform.position.z);

            collideUp = false;
            collideDown = false;
            collideLeft = false;
            collideRight = false;

            if (Physics2D.Raycast(boxCorner1, Vector2.up, moveSpeed, hitFilterMask) || Physics2D.Raycast(boxCorner2, Vector2.up, moveSpeed, hitFilterMask))
            {
                //if (moveVector.y > 0)
                {
                    moveVector = new Vector3(moveVector.x, transform.position.y, moveVector.z);
                    collideUp = true;
                }
            }
            if (Physics2D.Raycast(boxCorner3, Vector2.down, moveSpeed, hitFilterMask) || Physics2D.Raycast(boxCorner4, Vector2.down, moveSpeed, hitFilterMask))
            {
                //if (moveVector.y < 0)
                {
                    moveVector = new Vector3(moveVector.x, transform.position.y, moveVector.z);
                    collideDown = true;
                }
            }

            if (Physics2D.Raycast(boxCorner1, Vector2.left, moveSpeed, hitFilterMask) || Physics2D.Raycast(boxCorner4, Vector2.left, moveSpeed, hitFilterMask))
            {
                //if (moveVector.x < 0)
                {
                    moveVector = new Vector3(transform.position.x, moveVector.y, moveVector.z);
                    collideLeft = true;
                }
            }
            if (Physics2D.Raycast(boxCorner2, Vector2.right, moveSpeed, hitFilterMask) || Physics2D.Raycast(boxCorner3, Vector2.right, moveSpeed, hitFilterMask))
            {
                //if (moveVector.x > 0)
                {
                    moveVector = new Vector3(transform.position.x, moveVector.y, moveVector.z);
                    collideRight = true;
                }
            }

            //var vectorDifference = moveVector - transform.position;
            //transform.position += vectorDifference;

            if (targetPosition.y > transform.position.y + 34 && !collideUp)
            {
                transform.position += new Vector3(0, moveSpeed, 0);
            }
            else if (targetPosition.x > transform.position.x + 34 && !collideRight)
            {
                transform.position += new Vector3(moveSpeed, 0, 0);

            }
            else if (targetPosition.y < transform.position.y - 34 && !collideDown)
            {
                transform.position += new Vector3(0, -moveSpeed, 0);
            }
            else if (targetPosition.x < transform.position.x - 34 && !collideLeft)
            {
                transform.position += new Vector3(-moveSpeed, 0, 0);
            }


            
        }
        else if (dead)
        {
            //checking if player is within the bounds of the box2d
            if (touchingPlayer)
            {
                canBePickedUp = true;
            }
            else canBePickedUp = false;

            if (isPickedUp)
            {
                if (!heldByPlayer)
                {
                    heldVectorDifference = transform.position - playerObj.transform.position;
                    heldByPlayer = true;
                }
                transform.position = playerObj.transform.position + heldVectorDifference;
            }
            else heldByPlayer = false;
        }

	}

    void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.CompareTag("bullet"))
        {
            if (!dead)
            {
                var bulletDamage = collision.GetComponent<bulletController>().damage;
                Destroy(collision.gameObject);
                TakeDamage(bulletDamage);
                StartCoroutine(Flash());
                gameObject.layer = 0;
            }
        }
        if (collision.CompareTag("Player"))
        {
            touchingPlayer = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            touchingPlayer = false;
        }
    }

    void TakeDamage(float damage)
    {
        healthCurrent -= damage;
        audioSource1.clip = enemyHurt1;
        audioSource1.pitch = Random.Range(0.9f, 1.1f);
        audioSource1.Play();
        if (healthCurrent <= 0)
        {
            StartCoroutine(Die());
        }
    }

    IEnumerator Die()
    {
        dead = true;
        sightScript.Die();
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.2f);
        spriteRenderer.color = Color.red;
        //selfCollider.enabled = false;
        
    }

    IEnumerator Flash()
    {
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = Color.white;
    }
}
