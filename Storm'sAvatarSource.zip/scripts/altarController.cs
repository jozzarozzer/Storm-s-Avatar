﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class altarController : MonoBehaviour {

    public GameObject blood;
    public GameObject cloud;
    public GameObject flash;

    public AudioSource audioSource;
    public AudioSource audioSource2;
    public AudioSource audioSource3;
    public AudioClip blood1;
    public AudioClip thunder2;
    public AudioClip thunder1;

    public GameObject gameController;
    public GameObject player;

    public GameObject cameraObj;
    ShakeCamera cameraShake;

    public GameObject countNumerals;
    public Sprite numeral0;
    public Sprite numeral1;
    public Sprite numeral2;
    public Sprite numeral3;
    SpriteRenderer countNumeralsSpriteRenderer;
    int numeralCount;

    int bodyCount;
    public int bodiesNeeded = 3;
    Vector3 bodyPosition;

	// Use this for initialization
	void Start () {
        cameraShake = cameraObj.GetComponent<ShakeCamera>();
        countNumeralsSpriteRenderer = countNumerals.GetComponent<SpriteRenderer>();
        gameController = GameObject.Find("GameController");

    }
	
	// Update is called once per frame
	void Update () {
        if (numeralCount > 3)
        {
            numeralCount -= 3;
            return;
        }
		if (numeralCount == 0)
        {
            countNumeralsSpriteRenderer.sprite = numeral0;
        }
        else if (numeralCount == 1)
        {
            countNumeralsSpriteRenderer.sprite = numeral1;
        }
        else if (numeralCount == 2)
        {
            countNumeralsSpriteRenderer.sprite = numeral2;
        }
        else if (numeralCount == 3)
        {
            countNumeralsSpriteRenderer.sprite = numeral3;
        }
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        GameObject collisionObj = collision.gameObject;
        if (collision.CompareTag("enemy"))
        {
            enemyController collisionScript = collisionObj.GetComponent<enemyController>();
            if (collisionScript.dead && !collisionScript.isPickedUp)
            {
                Destroy(collisionObj);
                StartCoroutine(Sacrifice());
                bodyPosition = collisionObj.transform.position;
            }
        }
    }

    IEnumerator Sacrifice()
    {
        audioSource.clip = blood1;
        audioSource.pitch = Random.Range(0.9f, 1.1f);
        audioSource.Play();
        yield return new WaitForSeconds(0.1f);
        GameObject bloodObj = Instantiate(blood) as GameObject;
        bloodObj.transform.position = bodyPosition;
        cameraShake.shaking = false;
        cameraShake.Shake(0.75f, 20f);

        bodyCount++;
        numeralCount++;
        if (bodyCount >= bodiesNeeded)
        {
            bodyCount = 0;
            yield return new WaitForSeconds(1.5f);
            numeralCount = 0;
            player.GetComponent<playerController>().powerCurrent = player.GetComponent<playerController>().powerMax;
            gameController.GetComponent<gameControllerScript>().AltarUp(1);
            audioSource2.clip = thunder1;
            audioSource2.pitch = Random.Range(0.9f, 1.1f);
            audioSource2.Play();
            GameObject cloudObject = Instantiate(cloud) as GameObject;
            cloudObject.transform.position = transform.position;


            cameraShake.Shake(2f, 40f);

            yield return new WaitForSeconds(Random.Range(0.3f, 0.5f));
            flash.SetActive(true);
            audioSource3.clip = thunder2;
            audioSource3.pitch = Random.Range(0.9f, 1.1f);
            audioSource3.Play();
            yield return new WaitForSeconds(Random.Range(0.08f, 0.16f));
            flash.SetActive(false);
            if (Random.Range(0f, 0.999f) > 0.5f)
            {

                yield return new WaitForSeconds(Random.Range(0.1f, 0.6f));
                flash.SetActive(true);
                audioSource3.clip = thunder2;
                audioSource3.pitch = Random.Range(0.9f, 1.1f);
                audioSource3.Play();
                yield return new WaitForSeconds(Random.Range(0.08f, 0.16f));
                flash.SetActive(false);
                if (Random.Range(0f, 0.999f) > 0.5f)
                {

                    yield return new WaitForSeconds(Random.Range(0.1f, 0.6f));
                    flash.SetActive(true);
                    audioSource3.clip = thunder2;
                    audioSource3.pitch = Random.Range(0.9f, 1.1f);
                    audioSource3.Play();
                    yield return new WaitForSeconds(Random.Range(0.08f, 0.16f));
                    flash.SetActive(false);
                }
            }
        }
        

    }
}
