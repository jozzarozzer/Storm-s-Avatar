﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scoreScript : MonoBehaviour {

    public int score = 0;
    Text selfText;

	// Use this for initialization
	void Start () {
        selfText = GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
        selfText.text = ("Sacrifices: " + score);
	}

    public void AddScore(int amount)
    {
        score += amount;
    }
}
