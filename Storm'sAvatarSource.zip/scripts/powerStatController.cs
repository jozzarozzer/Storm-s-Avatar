﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class powerStatController : MonoBehaviour {

    public GameObject playerObj;
    playerController playerScript;
    Slider slider;

	// Use this for initialization
	void Start () {
        playerScript = playerObj.GetComponent<playerController>();
        slider = GetComponent<Slider>();
        slider.maxValue = playerScript.powerMax;
	}
	
	// Update is called once per frame
	void Update () {
        slider.value = playerScript.powerCurrent;
	}
}
