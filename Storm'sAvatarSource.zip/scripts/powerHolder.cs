﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class powerHolder : MonoBehaviour {

    public float powerMax;
    public float powerCurrent;
    public float powerExchange;

 
    public GameObject playerObj;
    public playerController playerScript;

    public GameObject powerSuckEntity;

    SpriteRenderer spriteRenderer;
    


    void Start()
    {
        playerScript = playerObj.GetComponent<playerController>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

	void Update () {

        

        spriteRenderer.color = new Color(0, 255, 255, powerCurrent/powerMax);
        if (powerCurrent <= 0)
        {
            powerCurrent = 0;
            //spriteRenderer.color = Color.grey;           
        }
        else
        {
            //spriteRenderer.color = Color.white;
        }
	}

    void SpawnPowerSuckEntity()
    {

        GameObject powerEntity = Instantiate(powerSuckEntity) as GameObject;
        powerEntity.transform.position = transform.position;
        var powerEntityScript = powerEntity.GetComponent<powerSuckEntityController>();
        powerEntityScript.playerObj = playerObj;
        powerEntityScript.SetValues(powerExchange);
    }

    public void OnMouseOver()
    {
        if (Input.GetMouseButton(1)){   //If Right click


                if (playerScript.powerCurrent < playerScript.powerMax)
                {
                    powerCurrent -= powerExchange;

                    SpawnPowerSuckEntity();
                    
            }
                else
                {

                }
        }
    }
}
