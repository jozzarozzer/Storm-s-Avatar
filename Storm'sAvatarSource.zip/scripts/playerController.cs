﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {

    private float hAxis;
    private float vAxis;
    public float speedMult;

    public float powerCurrent;
    public float powerMax;

    public GameObject gameOver;

    public float healthCurrent;
    public float healthMax;

    public float shootPowerRequirement;

    bool canSuckPower = true;

    private Vector3 moveVector;

    SpriteRenderer spriteRenderer;

    BoxCollider2D selfCollider;

    public GameObject spaceText;



    bool invincible = false;
    bool canFlash = true;

    bool leftWall;
    bool rightWall;
    bool upWall;
    bool downWall;

    public AudioSource audioSource1;
    public AudioClip playerHit1;

    GameObject corpse;
    public bool corpseIsHeld;

    Rigidbody2D rb2d;
    RaycastHit2D[] hitResults = new RaycastHit2D[16];
    List<RaycastHit2D> hitBufferList = new List<RaycastHit2D>(16);
    ContactFilter2D hitFilter;
    public LayerMask hitFilterMask;

    Color startColor;

	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        hitFilter.useLayerMask = true;
        hitFilter.layerMask = hitFilterMask;
        selfCollider = GetComponent<BoxCollider2D>();

        spriteRenderer = GetComponent<SpriteRenderer>();

        startColor = spriteRenderer.color;


	}
	
	// Update is called once per frame
	void Update () {

        if (powerCurrent > powerMax)
        {
            powerCurrent = powerMax;
        }

        hAxis = Input.GetAxis("Horizontal");
        vAxis = Input.GetAxis("Vertical");


        if (hAxis != 0 && vAxis != 0)
        {
            hAxis *= Mathf.Cos(Mathf.PI / 4);
            vAxis *= Mathf.Sin(Mathf.PI / 4);
        }

        moveVector = new Vector3(hAxis * speedMult, vAxis * speedMult, 0);

        var castDirection = new Vector2(moveVector.x, moveVector.y);


        


        //start top left, clockwise
        var boxCorner1 = new Vector3(transform.position.x - selfCollider.size.x / 2 - 1, transform.position.y + selfCollider.size.y / 2 + 1, transform.position.z);
        var boxCorner2 = new Vector3(transform.position.x + selfCollider.size.x / 2 + 1, transform.position.y + selfCollider.size.y / 2 + 1, transform.position.z);
        var boxCorner3 = new Vector3(transform.position.x + selfCollider.size.x / 2 + 1, transform.position.y - selfCollider.size.y / 2 - 1, transform.position.z);
        var boxCorner4 = new Vector3(transform.position.x - selfCollider.size.x / 2 - 1, transform.position.y - selfCollider.size.y / 2 - 1, transform.position.z);

        

        if (Physics2D.Raycast(boxCorner1, Vector2.up, speedMult, hitFilterMask) || Physics2D.Raycast(boxCorner2, Vector2.up, speedMult, hitFilterMask))
        {
            if (moveVector.y > 0)
            {
                moveVector = new Vector3(moveVector.x, 0, moveVector.z);
            }
        }
        if (Physics2D.Raycast(boxCorner3, Vector2.down, speedMult, hitFilterMask) || Physics2D.Raycast(boxCorner4, Vector2.down, speedMult, hitFilterMask))
        {
            if (moveVector.y < 0)
            {
                moveVector = new Vector3(moveVector.x, 0, moveVector.z);
            }
        }

        if (Physics2D.Raycast(boxCorner1, Vector2.left, speedMult, hitFilterMask) || Physics2D.Raycast(boxCorner4, Vector2.left, speedMult, hitFilterMask))
        {
            if (moveVector.x < 0)
            {
                moveVector = new Vector3(0, moveVector.y, moveVector.z);
            }
        }
        if (Physics2D.Raycast(boxCorner2, Vector2.right, speedMult, hitFilterMask) || Physics2D.Raycast(boxCorner3, Vector2.right, speedMult, hitFilterMask))
        {
            if (moveVector.x > 0)
            {
                moveVector = new Vector3(0, moveVector.y, moveVector.z);
            }
        }
        
        transform.position += moveVector;

        if (invincible && canFlash)
        {
            StartCoroutine(Flash());
        }

        

        if (corpse != null)
        {
            if (corpse.GetComponent<enemyController>().canBePickedUp)
            {

                if (Input.GetKey(KeyCode.Space))
                {
                    //if (!corpseIsHeld)
                    {
                        corpse.GetComponent<enemyController>().isPickedUp = true;
                        corpseIsHeld = true;
                    }
                }
                //else if (corpseIsHeld)
                else
                {
                    corpse.GetComponent<enemyController>().isPickedUp = false;
                    corpseIsHeld = false;
                }
                
                
            }
            else
            {
                corpse.GetComponent<enemyController>().isPickedUp = false;
                corpseIsHeld = false;
            }

        }

    }


    void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject collisionObj = collision.gameObject;
        if (collisionObj.CompareTag("powerSuckEntity"))
        {
            if (canSuckPower)
            {
                canSuckPower = false;
                powerCurrent += collisionObj.GetComponent<powerSuckEntityController>().powerHeld;
                Destroy(collisionObj);
                canSuckPower = true;
            }
        }
        if (collisionObj.CompareTag("enemy") && !invincible)
        {
            if (!collisionObj.GetComponent<enemyController>().dead)
            {
                var damage = 20;
                TakeDamage(damage);
            }
            else if (collisionObj.GetComponent<enemyController>().dead)
            {
                if (corpse != null)
                {
                    if (!corpseIsHeld && !corpse.GetComponent<enemyController>().isPickedUp)
                    {
                        corpse = collisionObj;
                    }
                }
                else corpse = collisionObj;
            }
        }

    }

    void TakeDamage(float damage)
    {
        healthCurrent -= damage;
        StartCoroutine(Invincibility());
        audioSource1.clip = playerHit1;
        audioSource1.pitch = Random.Range(0.9f, 1.1f);
        audioSource1.Play();
        if (healthCurrent <= 0)
        {
            Die();
        }
    }

    IEnumerator Invincibility()
    {
        invincible = true;
        yield return new WaitForSeconds(1);
        invincible = false;

    }
    IEnumerator Flash()
    {
        canFlash = false;
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = startColor;
        yield return new WaitForSeconds(0.1f);
        canFlash = true;
    }

    void Die()
    {
        gameOver.SetActive(true);
        Destroy(gameObject);
    }
}

