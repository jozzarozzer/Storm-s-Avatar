﻿using UnityEngine;
using System.Collections;

public class ShakeCamera : MonoBehaviour
{

    public static ShakeCamera Instance;
    public float time = 0.1f;
    public float amp = 0.25f;

    public bool shaking;
    private Vector3 pos;
    public bool isStatic;

    public Vector3 shakeVector;

    public smoothFollow cameraScript;

    void Start()
    {
        Instance = this;
        pos = transform.localPosition;
    }

    void Update()
    {
        if(!isStatic)
        {
            pos = transform.localPosition;
        }

        if (shaking)
        {
            //transform.localPosition = pos + Random.insideUnitSphere * amp;
            //shakeVector = pos + Random.insideUnitSphere * amp;
        }


    }

    public void Shake(float Time, float Amp)
    {
        time = Time;
        amp = Amp;
        shaking = true;
        Invoke("Stop", time);
    }

    void Stop()
    {
        shaking = false;
        transform.position = pos;
    }
}