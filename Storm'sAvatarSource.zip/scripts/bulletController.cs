﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletController : MonoBehaviour {

    Vector3 targetPosition;
    float moveSpeed;

    public float overshoot;
    public float lifeTime = 3;

    public Vector3 playerPosition;

    public float damage = 25;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        var targetPositionAlt = new Vector3((targetPosition.x * overshoot + playerPosition.x), (targetPosition.y * overshoot + playerPosition.y), -10);
        transform.position = Vector3.MoveTowards(transform.position, targetPositionAlt, moveSpeed);
        //targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

    }

    public void SetValues(Vector3 targetPos, float speed)
    {
        targetPosition = targetPos;
        moveSpeed = speed;
        Destroy(gameObject, lifeTime);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("wall"))
        {
            Destroy(gameObject);
        }
    }
}
