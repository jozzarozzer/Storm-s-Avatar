﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class detectSight : MonoBehaviour {

    public bool playerInSight;
    public GameObject followObj;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = followObj.transform.position;
        if (followObj.GetComponent<enemyController>().dead)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            playerInSight = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            playerInSight = false;
        }
    }

    public void Die()
    {
        Destroy(gameObject);
    }
}
