﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gunController : MonoBehaviour {

    public GameObject playerObj;
    SpriteRenderer spriteRenderer;



    Vector3 vectorDifference;

	// Use this for initialization
	void Start () {
        spriteRenderer = GetComponent<SpriteRenderer>();

	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.y > playerObj.transform.position.y)
        {
            spriteRenderer.sortingOrder = 1;
        }
        else spriteRenderer.sortingOrder = 3;

        if (transform.position.x > playerObj.transform.position.x)
        {
            vectorDifference = transform.position - playerObj.transform.position;
        }
        else vectorDifference = playerObj.transform.position - transform.position;

        transform.localEulerAngles = new Vector3 (0, 0, Mathf.Tan(vectorDifference.y / vectorDifference.x) * 180/Mathf.PI);
    }
}
