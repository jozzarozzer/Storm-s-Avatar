﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class powerSuckEntityController : MonoBehaviour {

    Vector3 targetPosition;
    public GameObject playerObj;

    public float lerpAmount = 0.1f;

    public float powerHeld;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        targetPosition = playerObj.transform.position;

        transform.position = Vector3.Lerp(transform.position, targetPosition, lerpAmount);
	}

    public void SetValues(float powerSuckAmount)
    {
        powerHeld = powerSuckAmount;
    }
}
