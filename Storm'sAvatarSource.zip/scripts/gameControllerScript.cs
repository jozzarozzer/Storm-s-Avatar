﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class gameControllerScript : MonoBehaviour {

    public int altarCount = 0;
    public int internalScore;

    public GameObject scoreText;

	// Use this for initialization
	void Start () {
        DontDestroyOnLoad(gameObject);
        scoreText = GameObject.Find("Score");
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.R))
        {
            Scene scene = SceneManager.GetSceneByBuildIndex(1);
            altarCount = 0;
            internalScore = 0;
            SceneManager.LoadScene(scene.name);
            
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (internalScore == 5)
        {
            NextLevel();
        }
	}

    public void AltarUp(int levels)
    {
        altarCount += levels;
        internalScore += levels;
        scoreText.GetComponent<scoreScript>().AddScore(levels);
    }

    void NextLevel()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        if (currentScene == SceneManager.GetSceneByBuildIndex(1))
        {
            SceneManager.LoadScene(2);
        }
        else if (currentScene == SceneManager.GetSceneByBuildIndex(2))
        {
            SceneManager.LoadScene(1);
        }
        else if (currentScene == SceneManager.GetSceneByBuildIndex(2))
        {
            SceneManager.LoadScene(1);
        }
    }

    void OnLevelWasLoaded()
    {
        internalScore = 0;
    }
}
